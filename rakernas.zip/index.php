<?php
/**
 * Landing Page / Halaman Utama
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH
 */

define('APP_INIT', true);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = getDB();

// Hitung statistik publik
$totalPeserta = 0;
$totalWilayah = 0;
$totalHadir = 0;
try {
    $totalPeserta = $pdo->query("SELECT COUNT(*) FROM participants WHERE status_verifikasi = 'verified'")->fetchColumn();
    $totalWilayah = $pdo->query("SELECT COUNT(DISTINCT pw_id) FROM participants WHERE status_verifikasi = 'verified'")->fetchColumn();
    $totalHadir   = $pdo->query("SELECT COUNT(*) FROM participants WHERE is_attended = 1")->fetchColumn();
} catch (Exception $e) {
    // Abaikan jika database baru
}

$page_title = "Beranda - RAKERNAS Perkumpulan Jama'ah Al Khidmah";
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Section with Emerald Green & Gold Elegance -->
<div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-alkhidmah-950 via-alkhidmah-900 to-alkhidmah-800 text-white p-8 md:p-12 mb-10 shadow-xl border border-alkhidmah-700/50">
    <!-- Subtle Islamic Star Pattern Decorative -->
    <div class="absolute -right-10 -bottom-10 w-96 h-96 opacity-10 pointer-events-none">
        <svg viewBox="0 0 200 200" fill="currentColor" class="w-full h-full text-gold-400">
            <polygon points="100,10 120,70 185,75 135,115 150,180 100,140 50,180 65,115 15,75 80,70"/>
        </svg>
    </div>

    <div class="relative z-10 max-w-3xl">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-alkhidmah-800/80 border border-alkhidmah-600/60 text-gold-400 text-xs font-semibold uppercase tracking-wider mb-4 shadow-sm">
            <span class="w-2 h-2 rounded-full bg-gold-400 animate-ping"></span>
            Aplikasi Resmi Registrasi & Presensi
        </div>

        <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-3 leading-tight">
            RAKERNAS PERKUMPULAN <br>
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-gold-400 via-amber-300 to-yellow-200">JAMA'AH AL KHIDMAH</span>
        </h1>

        <p class="text-emerald-100 text-base sm:text-lg mb-6 font-light leading-relaxed">
            <?= clean(getSetting('event_theme', 'Meneguhkan Khidmah, Menguatkan Ukhuwah, Menuju Kemandirian Jam\'iyyah')) ?>
        </p>

        <!-- Tanggal & Lokasi Badge -->
        <div class="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-emerald-200 mb-8">
            <div class="flex items-center gap-2 bg-alkhidmah-900/60 px-3.5 py-2 rounded-xl border border-alkhidmah-700/60">
                <svg class="w-4 h-4 text-gold-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                <span><?= clean(getSetting('event_date', '15 - 17 November 2026')) ?></span>
            </div>
            <div class="flex items-center gap-2 bg-alkhidmah-900/60 px-3.5 py-2 rounded-xl border border-alkhidmah-700/60">
                <svg class="w-4 h-4 text-gold-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <span><?= clean(getSetting('event_location', 'Pondok Pesantren Al Fithrah & Gedung Serbaguna')) ?></span>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex flex-wrap gap-3">
            <a href="<?= BASE_URL ?>check_status.php" class="px-6 py-3 rounded-xl bg-gradient-to-r from-gold-500 to-amber-500 text-slate-950 font-bold hover:from-gold-400 hover:to-amber-400 transition shadow-lg shadow-gold-500/20 flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                Cek Delegasi & E-ID Card
            </a>
            <?php if (!$user): ?>
                <a href="<?= BASE_URL ?>login.php" class="px-6 py-3 rounded-xl bg-alkhidmah-800/90 text-white font-semibold hover:bg-alkhidmah-700 border border-alkhidmah-600 transition flex items-center gap-2">
                    <svg class="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/></svg>
                    Portal Login Pengurus Wilayah
                </a>
            <?php else: ?>
                <a href="<?= $user['role'] === 'superadmin' ? BASE_URL.'admin/index.php' : BASE_URL.'pw/index.php' ?>" class="px-6 py-3 rounded-xl bg-white text-alkhidmah-900 font-bold hover:bg-emerald-50 transition flex items-center gap-2 shadow">
                    Masuk ke Dashboard <?= $user['role'] === 'superadmin' ? 'Panitia' : 'PW' ?> &rarr;
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Real-time Statistics Cards -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
    <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-4">
        <div class="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-alkhidmah-700">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        </div>
        <div>
            <div class="text-2xl font-extrabold text-slate-800"><?= number_format($totalPeserta) ?></div>
            <div class="text-xs font-medium text-slate-500 uppercase tracking-wider">Delegasi Terdaftar</div>
        </div>
    </div>

    <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-4">
        <div class="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-gold-600">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div>
            <div class="text-2xl font-extrabold text-slate-800"><?= number_format($totalWilayah) ?></div>
            <div class="text-xs font-medium text-slate-500 uppercase tracking-wider">Pengurus Wilayah (PW)</div>
        </div>
    </div>

    <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-4">
        <div class="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <div>
            <div class="text-2xl font-extrabold text-slate-800"><?= number_format($totalHadir) ?></div>
            <div class="text-xs font-medium text-slate-500 uppercase tracking-wider">Telah Check-in Hadir</div>
        </div>
    </div>
</div>

<!-- Features Section -->
<div class="mb-14">
    <div class="text-center max-w-xl mx-auto mb-10">
        <h2 class="text-2xl font-bold text-slate-900">Alur & Layanan Aplikasi Rakernas</h2>
        <p class="text-sm text-slate-500 mt-1">Kemudahan koordinasi kafilah dari seluruh penjuru nusantara</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Card 1: Pendaftaran Kolektif PW -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
            <div class="w-12 h-12 rounded-xl bg-alkhidmah-100 text-alkhidmah-800 flex items-center justify-center mb-4">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            </div>
            <h3 class="text-lg font-bold text-slate-800 mb-2">1. Pendaftaran Kolektif PW</h3>
            <p class="text-slate-600 text-sm leading-relaxed mb-4">
                Pengurus Wilayah (PW) dapat mendaftarkan delegasi utusan dan peninjau kabupaten/kota secara kolektif dengan kuota yang telah ditetapkan.
            </p>
            <a href="<?= BASE_URL ?>login.php" class="text-sm font-semibold text-alkhidmah-700 hover:text-alkhidmah-900 inline-flex items-center gap-1">
                Login Akun PW &rarr;
            </a>
        </div>

        <!-- Card 2: E-ID Card & QR Code -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
            <div class="w-12 h-12 rounded-xl bg-gold-100 text-gold-700 flex items-center justify-center mb-4">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2"/></svg>
            </div>
            <h3 class="text-lg font-bold text-slate-800 mb-2">2. E-ID Card & Akomodasi</h3>
            <p class="text-slate-600 text-sm leading-relaxed mb-4">
                Setiap peserta terverifikasi mendapatkan barcode QR Code unik, penetapan kamar wisma penginapan, dan pembagian komisi sidang.
            </p>
            <a href="<?= BASE_URL ?>check_status.php" class="text-sm font-semibold text-gold-700 hover:text-gold-800 inline-flex items-center gap-1">
                Cek & Cetak Mandiri &rarr;
            </a>
        </div>

        <!-- Card 3: Presensi Cepat di Lokasi -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition">
            <div class="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-4">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
            </div>
            <h3 class="text-lg font-bold text-slate-800 mb-2">3. Fast Check-in di Lokasi</h3>
            <p class="text-slate-600 text-sm leading-relaxed mb-4">
                Meja registrasi cukup memindai (scan) QR Code di HP atau ID Card peserta untuk validasi kehadiran langsung dan pengambilan kit Rakernas.
            </p>
            <a href="<?= BASE_URL ?>rundown.php" class="text-sm font-semibold text-purple-700 hover:text-purple-800 inline-flex items-center gap-1">
                Lihat Jadwal Kegiatan &rarr;
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
