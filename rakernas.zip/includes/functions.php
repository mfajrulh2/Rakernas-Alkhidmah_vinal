<?php
/**
 * Helper Functions
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH
 */

if (!defined('APP_INIT')) {
    require_once __DIR__ . '/../config/database.php';
}

/**
 * Sanitasi string input
 */
function clean($str) {
    return htmlspecialchars(trim($str ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Set flash alert session
 */
function setFlash($type, $message) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Render flash message jika ada
 */
function displayFlash() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);

        $bgColors = [
            'success' => 'bg-emerald-50 border-emerald-500 text-emerald-800',
            'danger'  => 'bg-rose-50 border-rose-500 text-rose-800',
            'warning' => 'bg-amber-50 border-amber-500 text-amber-800',
            'info'    => 'bg-blue-50 border-blue-500 text-blue-800'
        ];
        $icons = [
            'success' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />',
            'danger'  => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />',
            'warning' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />',
            'info'    => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />'
        ];

        $class = $bgColors[$flash['type']] ?? $bgColors['info'];
        $icon = $icons[$flash['type']] ?? $icons['info'];

        echo "
        <div class='mb-6 p-4 rounded-xl border-l-4 shadow-sm flex items-start gap-3 {$class} transition-all'>
            <svg class='w-5 h-5 flex-shrink-0 mt-0.5' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                {$icon}
            </svg>
            <div class='text-sm font-medium leading-relaxed'>" . clean($flash['message']) . "</div>
        </div>
        ";
    }
}

/**
 * Format tanggal Indonesia
 */
function formatTanggalIndo($dateStr, $withTime = false) {
    if (!$dateStr || $dateStr == '0000-00-00 00:00:00' || $dateStr == '0000-00-00') {
        return '-';
    }
    $bulanIndo = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $timestamp = strtotime($dateStr);
    $d = date('j', $timestamp);
    $m = $bulanIndo[(int)date('n', $timestamp)];
    $y = date('Y', $timestamp);

    $result = "{$d} {$m} {$y}";
    if ($withTime) {
        $result .= " pk " . date('H:i', $timestamp) . " WIB";
    }
    return $result;
}

/**
 * Generate QR Code URL menggunakan API gratis tanpa ketergantungan library luar
 */
function getQRCodeUrl($data, $size = 200) {
    $encoded = urlencode($data);
    return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data={$encoded}&margin=6";
}

/**
 * Generate Registration Code Unik
 * Contoh: RKN-JTM-042
 */
function generateRegistrationCode($pwCode) {
    $cleanPrefix = preg_replace('/[^A-Za-z0-9]/', '', str_replace('PW-', '', strtoupper($pwCode)));
    if (empty($cleanPrefix)) $cleanPrefix = 'GEN';
    $random = strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
    return 'RKN-' . $cleanPrefix . '-' . $random;
}

/**
 * Ambil Pengaturan dari Database
 */
function getSetting($key, $default = '') {
    static $settingsCache = null;
    if ($settingsCache === null) {
        $pdo = getDB();
        try {
            $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
            $settingsCache = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        } catch (Exception $e) {
            $settingsCache = [];
        }
    }
    return $settingsCache[$key] ?? $default;
}

/**
 * Ambil URL Logo Aplikasi (jika ada yang diupload)
 */
function getAppLogoUrl() {
    $logo = getSetting('app_logo', '');
    if (!empty($logo) && file_exists(__DIR__ . '/../' . $logo)) {
        return BASE_URL . $logo;
    }
    return null;
}

/**
 * Tipe badge peserta dengan warna elegan
 */
function renderParticipantBadge($type) {
    switch (strtolower($type)) {
        case 'utusan':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Utusan</span>';
        case 'peninjau':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Peninjau</span>';
        case 'pengurus_pusat':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-300">Pengurus Pusat</span>';
        case 'undangan':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-300">Undangan</span>';
        default:
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-800 border border-gray-300">' . clean(ucfirst($type)) . '</span>';
    }
}

/**
 * Tipe status kehadiran
 */
function renderAttendanceBadge($isAttended, $attendedAt = null) {
    if ($isAttended) {
        $time = $attendedAt ? "<br><span class='text-[10px] text-emerald-600'>" . date('H:i', strtotime($attendedAt)) . " WIB</span>" : "";
        return '<span class="inline-flex flex-col items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-300">
                    <span class="flex items-center gap-1"><svg class="w-3.5 h-3.5 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg> Hadir</span>' . $time . '
                </span>';
    }
    return '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-600 border border-gray-300">Belum Hadir</span>';
}

/**
 * Format Angka ke Rupiah
 */
function formatRupiah($nominal) {
    return 'Rp ' . number_format((float)$nominal, 0, ',', '.');
}

/**
 * Pastikan Tabel Payments & Pengaturan Terkait Sudah Tersedia (Auto Migration)
 */
function ensurePaymentTableExists() {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $pdo = getDB();
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `payments` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `invoice_code` VARCHAR(50) NOT NULL UNIQUE,
              `pw_id` INT NOT NULL,
              `total_participants` INT NOT NULL DEFAULT 0,
              `amount_per_person` DECIMAL(15,2) NOT NULL DEFAULT 0,
              `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0,
              `bank_name` VARCHAR(80) DEFAULT NULL,
              `account_number` VARCHAR(80) DEFAULT NULL,
              `sender_name` VARCHAR(120) DEFAULT NULL,
              `payment_date` DATE DEFAULT NULL,
              `proof_file` VARCHAR(255) DEFAULT NULL,
              `status` ENUM('unpaid', 'pending', 'verified', 'rejected') NOT NULL DEFAULT 'unpaid',
              `verified_by` INT DEFAULT NULL,
              `verified_at` DATETIME DEFAULT NULL,
              `reject_reason` TEXT DEFAULT NULL,
              `notes` TEXT DEFAULT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              CONSTRAINT `fk_payments_pw` FOREIGN KEY (`pw_id`) REFERENCES `wilayah` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        // Insert default iuran settings if not set
        $pdo->exec("
            INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES
            ('fee_per_participant', '350000'),
            ('payment_bank_name', 'Bank Syariah Indonesia (BSI)'),
            ('payment_account_no', '7123456789'),
            ('payment_account_name', 'Bendahara RAKERNAS Al Khidmah'),
            ('payment_instructions', 'Transfer sesuai nominal tagihan delegasi ke rekening resmi panitia. Cantumkan berita transfer: IURAN [KODE PW] (contoh: IURAN PW-JATIM). Setelah transfer, unggah bukti pembayaran di portal ini.');
        ");
    } catch (Exception $e) {
        // Abaikan jika tabel sudah ada atau permission terbatas
    }
}

/**
 * Cek status pembayaran dan rincian iuran PW
 */
function getPWPaymentInfo($pw_id) {
    ensurePaymentTableExists();
    $pdo = getDB();

    // Hitung total delegasi terdaftar untuk PW ini
    $stmtC = $pdo->prepare("SELECT COUNT(*) FROM participants WHERE pw_id = ?");
    $stmtC->execute([$pw_id]);
    $totalPeserta = (int)$stmtC->fetchColumn();

    $feePerPerson = (float)getSetting('fee_per_participant', '350000');
    $expectedTotal = $totalPeserta * $feePerPerson;

    // Ambil pembayaran terakhir
    $stmtP = $pdo->prepare("SELECT * FROM payments WHERE pw_id = ? ORDER BY id DESC LIMIT 1");
    $stmtP->execute([$pw_id]);
    $payment = $stmtP->fetch() ?: null;

    $status = $payment ? $payment['status'] : ($totalPeserta > 0 ? 'unpaid' : 'unpaid');
    $isVerified = ($status === 'verified');

    return [
        'status'              => $status,
        'is_verified'         => $isVerified,
        'payment'             => $payment,
        'total_participants'  => $totalPeserta,
        'fee_per_person'      => $feePerPerson,
        'expected_total'      => $expectedTotal
    ];
}

/**
 * Hitung jumlah pembayaran yang butuh validasi (pending)
 */
function countPendingPayments() {
    ensurePaymentTableExists();
    $pdo = getDB();
    try {
        return (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'")->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * Tipe badge status pembayaran
 */
function renderPaymentBadge($status) {
    switch (strtolower($status)) {
        case 'verified':
            return '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        <svg class="w-3.5 h-3.5 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                        Lunas / Terverifikasi
                    </span>';
        case 'pending':
            return '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
                        <svg class="w-3.5 h-3.5 text-amber-600 animate-pulse" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"></path></svg>
                        Menunggu Validasi
                    </span>';
        case 'rejected':
            return '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
                        <svg class="w-3.5 h-3.5 text-rose-600" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>
                        Ditolak
                    </span>';
        default:
            return '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-300">
                        Belum Konfirmasi
                    </span>';
    }
}

/**
 * Pastikan Kolom Baru pada Tabel Participants Sudah Tersedia (Auto Migration)
 */
function ensureParticipantColumnsExist() {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $pdo = getDB();
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM `participants`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('unsur_organisasi', $cols)) {
            $pdo->exec("ALTER TABLE `participants` ADD COLUMN `unsur_organisasi` VARCHAR(80) NOT NULL DEFAULT 'Al Khidmah' AFTER `gender`");
        }
        if (!in_array('photo_file', $cols)) {
            $pdo->exec("ALTER TABLE `participants` ADD COLUMN `photo_file` VARCHAR(255) DEFAULT NULL AFTER `phone`");
        }
    } catch (Exception $e) {
        // Abaikan jika gagal
    }
}
ensureParticipantColumnsExist();

/**
 * Daftar Pilihan Unsur Organisasi
 */
function getUnsurOrganisasiOptions() {
    return [
        'Al Khidmah',
        'Ath Thoriqoh',
        'UCC'
    ];
}

/**
 * Daftar Pilihan Komisi Sidang
 */
function getKomisiOptions() {
    return [
        'A. Bidang Organisasi',
        'B. Bidang Kemajlisan & Kethoriqohan',
        'C. Bidang Usaha Ekonomi',
        'D. Bidang Kepemudaan',
        'E. Bidang IT dan Multimedia'
    ];
}

/**
 * Render Badge Unsur Organisasi
 */
function renderUnsurBadge($unsur) {
    $u = trim($unsur ?: 'Al Khidmah');
    switch ($u) {
        case 'Ath Thoriqoh':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Ath Thoriqoh</span>';
        case 'UCC':
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">UCC</span>';
        default:
            return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">' . clean($u) . '</span>';
    }
}

/**
 * Helper Upload Foto Peserta (Maks 5 MB, JPG/PNG/WebP)
 */
function uploadParticipantPhoto($fileData, $index = null) {
    $name     = $index !== null ? ($fileData['name'][$index] ?? '') : ($fileData['name'] ?? '');
    $tmpName  = $index !== null ? ($fileData['tmp_name'][$index] ?? '') : ($fileData['tmp_name'] ?? '');
    $error    = $index !== null ? ($fileData['error'][$index] ?? UPLOAD_ERR_NO_FILE) : ($fileData['error'] ?? UPLOAD_ERR_NO_FILE);
    $size     = $index !== null ? ($fileData['size'][$index] ?? 0) : ($fileData['size'] ?? 0);

    if ($error === UPLOAD_ERR_NO_FILE || empty($name)) {
        return ['uploaded' => false, 'path' => null, 'error' => null];
    }

    if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE || $size > 5 * 1024 * 1024) {
        return ['uploaded' => false, 'path' => null, 'error' => 'Ukuran file foto melebihi batas maksimal 5 MB.'];
    }

    if ($error !== UPLOAD_ERR_OK) {
        return ['uploaded' => false, 'path' => null, 'error' => 'Gagal mengunggah file foto (Error code: ' . $error . ').'];
    }

    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'webp'];
    if (!in_array($ext, $allowedExts)) {
        return ['uploaded' => false, 'path' => null, 'error' => 'Format foto tidak didukung. Gunakan file JPG, JPEG, PNG, atau WebP.'];
    }

    $uploadDir = __DIR__ . '/../uploads/participants/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $filename = 'foto_' . time() . '_' . substr(bin2hex(random_bytes(3)), 0, 6) . '.' . $ext;
    $targetPath = $uploadDir . $filename;

    if (move_uploaded_file($tmpName, $targetPath)) {
        return ['uploaded' => true, 'path' => 'uploads/participants/' . $filename, 'error' => null];
    }

    return ['uploaded' => false, 'path' => null, 'error' => 'Gagal menyimpan file foto ke server.'];
}

/**
 * Auto-migration: Pastikan kolom reg_token ada di tabel wilayah dan terisi token unik
 */
function ensureWilayahRegTokenExists() {
    static $checked = false;
    if ($checked) return;
    $checked = true;

    $pdo = getDB();
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM `wilayah`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('reg_token', $cols)) {
            $pdo->exec("ALTER TABLE `wilayah` ADD COLUMN `reg_token` VARCHAR(64) DEFAULT NULL UNIQUE AFTER `contact_phone`");
        }

        // Cek jika ada wilayah yang belum memiliki reg_token
        $stmtNull = $pdo->query("SELECT id FROM `wilayah` WHERE `reg_token` IS NULL OR `reg_token` = ''");
        $emptyList = $stmtNull->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($emptyList)) {
            $stmtUp = $pdo->prepare("UPDATE `wilayah` SET `reg_token` = ? WHERE `id` = ?");
            foreach ($emptyList as $wId) {
                $newToken = bin2hex(random_bytes(16)); // 32 hex chars
                $stmtUp->execute([$newToken, $wId]);
            }
        }
    } catch (Exception $e) {
        // Abaikan jika tabel belum siap
    }
}
ensureWilayahRegTokenExists();

/**
 * Ambil data wilayah berdasarkan registration token
 */
function getWilayahByRegToken($token) {
    if (empty($token)) return false;
    $pdo = getDB();
    try {
        $stmt = $pdo->prepare("SELECT * FROM `wilayah` WHERE `reg_token` = ? LIMIT 1");
        $stmt->execute([trim($token)]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Generate URL registrasi khusus PW
 */
function getPWRegistrationUrl($token) {
    if (empty($token)) return '#';
    return rtrim(BASE_URL, '/') . '/daftar.php?token=' . urlencode($token);
}

/**
 * Regenerate registration token untuk suatu PW
 */
function regeneratePWRegToken($pwId) {
    $pdo = getDB();
    $newToken = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare("UPDATE `wilayah` SET `reg_token` = ? WHERE `id` = ?");
    $stmt->execute([$newToken, (int)$pwId]);
    return $newToken;
}
