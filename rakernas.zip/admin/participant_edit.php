<?php
/**
 * Form Edit Data Delegasi (Admin Pusat)
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH
 */

define('APP_INIT', true);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['superadmin', 'petugas_scan']);

$pdo = getDB();
$id = (int)($_GET['id'] ?? 0);

$stmtP = $pdo->prepare("SELECT * FROM participants WHERE id = ?");
$stmtP->execute([$id]);
$p = $stmtP->fetch();

if (!$p) {
    setFlash('danger', 'Data peserta tidak ditemukan.');
    header("Location: " . BASE_URL . "admin/participants.php");
    exit;
}

$unsurOptions  = getUnsurOrganisasiOptions();
$komisiOptions = getKomisiOptions();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name        = trim($_POST['full_name'] ?? '');
    $gender           = trim($_POST['gender'] ?? 'L');
    $unsur_organisasi = trim($_POST['unsur_organisasi'] ?? 'Al Khidmah');
    $pd_name          = trim($_POST['pd_name'] ?? '');
    $jabatan          = trim($_POST['jabatan_organisasi'] ?? '');
    $komisi           = trim($_POST['komisi'] ?? $komisiOptions[0]);
    $phone            = trim($_POST['phone'] ?? '');
    $nik              = trim($_POST['nik'] ?? '');
    $email            = trim($_POST['email'] ?? '');
    $pw_id            = (int)($_POST['pw_id'] ?? 0);
    $type             = trim($_POST['participant_type'] ?? 'utusan');
    $room_id          = !empty($_POST['room_id']) ? (int)$_POST['room_id'] : null;
    $notes            = trim($_POST['notes'] ?? '');
    $status_verif     = trim($_POST['status_verifikasi'] ?? 'verified');

    if (empty($full_name)) $errors[] = "Nama lengkap wajib diisi.";
    if (empty($phone)) $errors[] = "Nomor WhatsApp wajib diisi.";
    if ($pw_id <= 0) $errors[] = "Pengurus Wilayah (PW) wajib dipilih.";

    $photoPath = $p['photo_file'] ?? null;
    // Cek jika ada upload foto baru
    if (isset($_FILES['photo_file']) && !empty($_FILES['photo_file']['name'])) {
        $photoUpload = uploadParticipantPhoto($_FILES['photo_file']);
        if ($photoUpload['error']) {
            $errors[] = $photoUpload['error'];
        } else {
            $photoPath = $photoUpload['path'];
        }
    }

    if (empty($errors)) {
        $stmtUp = $pdo->prepare("
            UPDATE participants SET 
                full_name = ?, gender = ?, unsur_organisasi = ?, phone = ?, nik = ?, email = ?, photo_file = ?,
                pw_id = ?, pd_name = ?, jabatan_organisasi = ?, participant_type = ?, 
                komisi = ?, room_id = ?, status_verifikasi = ?, notes = ?
            WHERE id = ?
        ");
        $stmtUp->execute([
            $full_name, $gender, $unsur_organisasi, $phone, $nik, $email, $photoPath,
            $pw_id, $pd_name, $jabatan, $type,
            $komisi, $room_id, $status_verif, $notes,
            $id
        ]);

        setFlash('success', "Data delegasi {$full_name} berhasil diperbarui.");
        header("Location: " . BASE_URL . "admin/participants.php");
        exit;
    }
}

// Ambil list Wilayah
$wilayahList = $pdo->query("SELECT id, name, code FROM wilayah ORDER BY name ASC")->fetchAll();

// Ambil list Kamar
$roomList = $pdo->query("SELECT id, building_name, room_number, gender, capacity FROM rooms ORDER BY building_name ASC, room_number ASC")->fetchAll();

$page_title = "Edit Delegasi - " . clean($p['full_name']);
require_once __DIR__ . '/../includes/header.php';
?>

<div class="max-w-3xl mx-auto mb-16">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <div class="inline-flex items-center gap-1.5 font-mono text-xs font-bold text-slate-500 mb-1">
                Kode: <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"><?= clean($p['registration_code']) ?></span>
            </div>
            <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Edit Data Delegasi</h1>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?= BASE_URL ?>print_card.php?code=<?= urlencode($p['registration_code']) ?>" target="_blank" class="px-3.5 py-2 rounded-xl bg-alkhidmah-50 border border-alkhidmah-300 text-alkhidmah-800 text-xs font-bold hover:bg-alkhidmah-100 transition flex items-center gap-1.5">
                <svg class="w-4 h-4 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                ID Card
            </a>
            <a href="<?= BASE_URL ?>admin/participants.php" class="px-4 py-2 rounded-xl bg-white border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition">
                &larr; Kembali
            </a>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs space-y-1">
            <?php foreach ($errors as $err): ?>
                <div>• <?= clean($err) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8">
        <form action="" method="POST" enctype="multipart/form-data" class="space-y-6">
            <!-- Identitas Delegasi -->
            <div>
                <h3 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 mb-4 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-600"></span>
                    Identitas Delegasi
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Nama Lengkap & Gelar *</label>
                        <input type="text" name="full_name" required value="<?= clean($_POST['full_name'] ?? $p['full_name']) ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Jenis Kelamin *</label>
                        <select name="gender" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white">
                            <?php $currGender = $_POST['gender'] ?? $p['gender']; ?>
                            <option value="L" <?= $currGender === 'L' ? 'selected' : '' ?>>Laki-laki (L)</option>
                            <option value="P" <?= $currGender === 'P' ? 'selected' : '' ?>>Perempuan (P)</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Unsur Organisasi *</label>
                        <select name="unsur_organisasi" required class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white font-semibold text-emerald-800">
                            <?php $currUnsur = $_POST['unsur_organisasi'] ?? ($p['unsur_organisasi'] ?? 'Al Khidmah'); ?>
                            <?php foreach ($unsurOptions as $uo): ?>
                                <option value="<?= clean($uo) ?>" <?= $currUnsur === $uo ? 'selected' : '' ?>><?= clean($uo) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Nomor WhatsApp *</label>
                        <input type="text" name="phone" required value="<?= clean($_POST['phone'] ?? $p['phone']) ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">NIK (KTP)</label>
                        <input type="text" name="nik" value="<?= clean($_POST['nik'] ?? $p['nik']) ?>" placeholder="16 Digit NIK" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <!-- Upload & Preview Foto -->
                    <div class="sm:col-span-2">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Foto Delegasi</label>
                        <div class="flex items-center gap-4">
                            <?php if (!empty($p['photo_file'])): ?>
                                <div class="relative shrink-0">
                                    <img src="<?= BASE_URL . clean($p['photo_file']) ?>" alt="Foto" class="w-16 h-20 object-cover rounded-xl border-2 border-emerald-500 shadow-sm">
                                    <span class="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5" title="Foto tersimpan">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="w-16 h-20 rounded-xl bg-slate-100 border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 shrink-0">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                    <span class="text-[9px] mt-0.5">No photo</span>
                                </div>
                            <?php endif; ?>
                            <div class="flex-grow">
                                <input type="file" name="photo_file" accept=".jpg,.jpeg,.png,.webp" onchange="validateAdminPhotoSize(this)" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-50 file:text-emerald-700 file:font-semibold hover:file:bg-emerald-100 transition">
                                <p class="text-[11px] text-amber-700 mt-1 font-medium flex items-center gap-1">
                                    <svg class="w-3.5 h-3.5 text-amber-500 inline shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
                                    upload file foto dengan mengenakan baju dan kopiah putih - ukuran maks 5 Mb
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Asal Wilayah & Organisasi -->
            <div>
                <h3 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 mb-4 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                    Asal Wilayah & Jabatan
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Pengurus Wilayah (PW) *</label>
                        <select name="pw_id" required class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white">
                            <?php $currPW = (int)($_POST['pw_id'] ?? $p['pw_id']); ?>
                            <?php foreach ($wilayahList as $w): ?>
                                <option value="<?= $w['id'] ?>" <?= $currPW === (int)$w['id'] ? 'selected' : '' ?>><?= clean($w['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Pengurus Daerah</label>
                        <input type="text" name="pd_name" value="<?= clean($_POST['pd_name'] ?? $p['pd_name']) ?>" placeholder="Contoh: PD Al Khidmah Surabaya" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Jabatan / Bidang</label>
                        <input type="text" name="jabatan_organisasi" value="<?= clean($_POST['jabatan_organisasi'] ?? $p['jabatan_organisasi']) ?>" placeholder="Contoh: Ketua / Sekretaris / Anggota" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Klasifikasi Peserta *</label>
                        <select name="participant_type" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white">
                            <?php $currType = $_POST['participant_type'] ?? $p['participant_type']; ?>
                            <option value="utusan" <?= $currType === 'utusan' ? 'selected' : '' ?>>Peserta Utusan (Hak Suara & Bicara)</option>
                            <option value="peninjau" <?= $currType === 'peninjau' ? 'selected' : '' ?>>Peserta Peninjau (Hak Bicara)</option>
                            <option value="pengurus_pusat" <?= $currType === 'pengurus_pusat' ? 'selected' : '' ?>>Pengurus Pusat</option>
                            <option value="undangan" <?= $currType === 'undangan' ? 'selected' : '' ?>>Undangan Khusus</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Sidang Komisi & Penginapan -->
            <div>
                <h3 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 mb-4 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                    Sidang Komisi & Fasilitas Kamar
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Komisi Sidang *</label>
                        <select name="komisi" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white font-semibold text-slate-800">
                            <?php $currKomisi = $_POST['komisi'] ?? $p['komisi']; ?>
                            <?php foreach ($komisiOptions as $ko): ?>
                                <option value="<?= clean($ko) ?>" <?= $currKomisi === $ko ? 'selected' : '' ?>><?= clean($ko) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Kamar Penginapan</label>
                        <select name="room_id" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white">
                            <option value="">-- Tentukan Nanti --</option>
                            <?php $currRoom = $_POST['room_id'] ?? $p['room_id']; ?>
                            <?php foreach ($roomList as $r): ?>
                                <option value="<?= $r['id'] ?>" <?= (int)$currRoom === (int)$r['id'] ? 'selected' : '' ?>>
                                    <?= clean($r['building_name']) ?> - <?= clean($r['room_number']) ?> (<?= $r['gender'] == 'L' ? 'Ikhwan' : 'Akhwat' ?>, Kapasitas <?= $r['capacity'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Status Verifikasi</label>
                        <select name="status_verifikasi" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none bg-white">
                            <?php $currVerif = $_POST['status_verifikasi'] ?? $p['status_verifikasi']; ?>
                            <option value="verified" <?= $currVerif === 'verified' ? 'selected' : '' ?>>Terverifikasi</option>
                            <option value="pending" <?= $currVerif === 'pending' ? 'selected' : '' ?>>Pending / Menunggu</option>
                            <option value="rejected" <?= $currVerif === 'rejected' ? 'selected' : '' ?>>Ditolak</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Email (Opsional)</label>
                        <input type="email" name="email" value="<?= clean($_POST['email'] ?? $p['email']) ?>" placeholder="delegasi@alkhidmah.org" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none">
                    </div>

                    <div class="sm:col-span-2">
                        <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Catatan Khusus (Opsional)</label>
                        <textarea name="notes" rows="2" placeholder="Catatan khusus..." class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-alkhidmah-600 focus:outline-none"><?= clean($_POST['notes'] ?? $p['notes']) ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Submit -->
            <div class="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <a href="<?= BASE_URL ?>admin/participants.php" class="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition">
                    Batal
                </a>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-emerald-700 text-white font-bold text-xs hover:bg-emerald-800 transition shadow-sm">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function validateAdminPhotoSize(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const maxBytes = 5 * 1024 * 1024;
        if (file.size > maxBytes) {
            alert('Ukuran file foto melebihi 5 MB (' + (file.size / (1024 * 1024)).toFixed(2) + ' MB). Silakan pilih foto dengan ukuran maksimal 5 MB.');
            input.value = '';
        }
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
