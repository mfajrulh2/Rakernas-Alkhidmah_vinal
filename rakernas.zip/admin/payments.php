<?php
/**
 * Validasi Pembayaran Iuran Delegasi - Halaman Admin / Panitia Pusat
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH
 */

define('APP_INIT', true);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('superadmin');
ensurePaymentTableExists();

$pdo  = getDB();
$user = currentUser();

// =============================================
// HANDLE AJAX / POST ACTIONS
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    $paymentId = (int)($_POST['payment_id'] ?? 0);
    if (!$paymentId) {
        echo json_encode(['success' => false, 'message' => 'ID pembayaran tidak valid.']);
        exit;
    }

    // Ambil data payment
    $stmtP = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
    $stmtP->execute([$paymentId]);
    $payment = $stmtP->fetch();

    if (!$payment) {
        echo json_encode(['success' => false, 'message' => 'Data pembayaran tidak ditemukan.']);
        exit;
    }

    if ($_POST['action'] === 'verify') {
        $pdo->prepare("
            UPDATE payments SET
                status = 'verified',
                verified_by = ?,
                verified_at = NOW(),
                reject_reason = NULL,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([$user['id'], $paymentId]);

        echo json_encode(['success' => true, 'message' => 'Pembayaran berhasil diverifikasi! Status PW: LUNAS.']);
        exit;

    } elseif ($_POST['action'] === 'reject') {
        $reason = trim($_POST['reject_reason'] ?? '');
        if (empty($reason)) {
            echo json_encode(['success' => false, 'message' => 'Alasan penolakan wajib diisi.']);
            exit;
        }

        $pdo->prepare("
            UPDATE payments SET
                status = 'rejected',
                verified_by = ?,
                verified_at = NOW(),
                reject_reason = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([$user['id'], $reason, $paymentId]);

        echo json_encode(['success' => true, 'message' => 'Pembayaran ditolak. PW akan diminta kirim ulang konfirmasi.']);
        exit;

    } elseif ($_POST['action'] === 'reset') {
        // Reset ke unpaid
        $pdo->prepare("
            UPDATE payments SET
                status = 'unpaid',
                verified_by = NULL,
                verified_at = NULL,
                reject_reason = NULL,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([$paymentId]);

        echo json_encode(['success' => true, 'message' => 'Status pembayaran direset ke Belum Konfirmasi.']);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Aksi tidak dikenal.']);
    exit;
}

// =============================================
// DATA STATISTIK
// =============================================
$filterStatus = $_GET['status'] ?? 'all';
$validStatuses = ['all', 'pending', 'verified', 'rejected', 'unpaid'];
if (!in_array($filterStatus, $validStatuses)) $filterStatus = 'all';

// Hitung stat cards
$statTotal   = (int)$pdo->query("SELECT COUNT(*) FROM wilayah")->fetchColumn();
$statVerified = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'verified'")->fetchColumn();
$statPending  = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'pending'")->fetchColumn();
$statRejected = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'rejected'")->fetchColumn();
$totalVerifiedAmount = (float)$pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM payments WHERE status = 'verified'")->fetchColumn();

$feePerPerson = (float)getSetting('fee_per_participant', '350000');

// Query semua data PW beserta info pembayaran
$sql = "
    SELECT
        w.id AS pw_id,
        w.name AS pw_name,
        w.code AS pw_code,
        COUNT(p.id) AS total_participants,
        (COUNT(p.id) * :fee) AS expected_total,
        pay.id AS payment_id,
        pay.invoice_code,
        pay.total_amount,
        pay.bank_name,
        pay.sender_name,
        pay.payment_date,
        pay.proof_file,
        pay.status AS pay_status,
        pay.reject_reason,
        pay.verified_at,
        pay.notes,
        pay.created_at AS submitted_at
    FROM wilayah w
    LEFT JOIN participants p ON p.pw_id = w.id
    LEFT JOIN payments pay ON pay.pw_id = w.id AND pay.id = (
        SELECT id FROM payments WHERE pw_id = w.id ORDER BY id DESC LIMIT 1
    )
    WHERE w.id > 0
";

$params = [':fee' => $feePerPerson];

if ($filterStatus === 'unpaid') {
    $sql .= " AND (pay.id IS NULL OR pay.status = 'rejected')";
} elseif ($filterStatus !== 'all') {
    $sql .= " AND pay.status = :status";
    $params[':status'] = $filterStatus;
}

$sql .= " GROUP BY w.id ORDER BY
    CASE COALESCE(pay.status,'unpaid')
        WHEN 'pending'  THEN 1
        WHEN 'rejected' THEN 2
        WHEN 'unpaid'   THEN 3
        WHEN 'verified' THEN 4
    END, pay.created_at DESC";

$stmtList = $pdo->prepare($sql);
$stmtList->execute($params);
$pwPayments = $stmtList->fetchAll();

$page_title = 'Validasi Pembayaran';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div class="flex items-center gap-3">
            <div class="p-2 bg-amber-100 rounded-xl">
                <svg class="w-7 h-7 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-slate-800">Validasi Pembayaran Iuran</h1>
                <p class="text-sm text-slate-500">Panitia Pusat — Verifikasi Konfirmasi Pembayaran PW • Iuran Saat Ini: <strong class="text-amber-700"><?= formatRupiah($feePerPerson) ?> / orang</strong></p>
            </div>
        </div>
        <a href="<?= BASE_URL ?>admin/settings.php?tab=payment" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            <span>Atur Nominal Iuran & Rekening</span>
        </a>
    </div>

    <!-- Stat Cards -->
    <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 text-center">
            <div class="text-2xl font-extrabold text-slate-800"><?= $statTotal ?></div>
            <div class="text-xs text-slate-500 mt-1">Total PW Aktif</div>
        </div>
        <a href="?status=pending" class="bg-amber-50 rounded-2xl border-2 <?= $filterStatus === 'pending' ? 'border-amber-500' : 'border-amber-200' ?> shadow-sm p-4 text-center hover:border-amber-400 transition block">
            <div class="text-2xl font-extrabold text-amber-700"><?= $statPending ?></div>
            <div class="text-xs text-amber-600 mt-1 font-medium">Menunggu Validasi</div>
        </a>
        <a href="?status=verified" class="bg-emerald-50 rounded-2xl border-2 <?= $filterStatus === 'verified' ? 'border-emerald-500' : 'border-emerald-200' ?> shadow-sm p-4 text-center hover:border-emerald-400 transition block">
            <div class="text-2xl font-extrabold text-emerald-700"><?= $statVerified ?></div>
            <div class="text-xs text-emerald-600 mt-1 font-medium">Terverifikasi (Lunas)</div>
        </a>
        <a href="?status=rejected" class="bg-rose-50 rounded-2xl border-2 <?= $filterStatus === 'rejected' ? 'border-rose-500' : 'border-rose-200' ?> shadow-sm p-4 text-center hover:border-rose-400 transition block">
            <div class="text-2xl font-extrabold text-rose-700"><?= $statRejected ?></div>
            <div class="text-xs text-rose-600 mt-1 font-medium">Ditolak</div>
        </a>
        <div class="bg-alkhidmah-50 rounded-2xl border border-alkhidmah-200 shadow-sm p-4 text-center md:col-span-1">
            <div class="text-sm font-extrabold text-alkhidmah-800 leading-tight"><?= formatRupiah($totalVerifiedAmount) ?></div>
            <div class="text-xs text-alkhidmah-600 mt-1 font-medium">Total Dana Terverifikasi</div>
        </div>
    </div>

    <!-- Filter Tab -->
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-1 flex gap-1 flex-wrap">
        <?php
        $tabs = [
            'all'      => ['Semua PW', 'slate'],
            'pending'  => ['Menunggu Validasi', 'amber'],
            'verified' => ['Terverifikasi', 'emerald'],
            'rejected' => ['Ditolak', 'rose'],
            'unpaid'   => ['Belum Konfirmasi', 'gray'],
        ];
        foreach ($tabs as $key => [$label, $color]):
            $isActive = $filterStatus === $key;
        ?>
        <a href="?status=<?= $key ?>"
           class="px-4 py-2 rounded-lg text-sm font-semibold transition <?= $isActive ? "bg-{$color}-100 text-{$color}-800 border border-{$color}-300" : 'text-slate-600 hover:bg-slate-50' ?>">
            <?= $label ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Tabel Data -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th class="px-4 py-3 text-left font-semibold text-slate-600">PW</th>
                        <th class="px-4 py-3 text-center font-semibold text-slate-600">Delegasi</th>
                        <th class="px-4 py-3 text-right font-semibold text-slate-600">Tagihan</th>
                        <th class="px-4 py-3 text-left font-semibold text-slate-600">Status</th>
                        <th class="px-4 py-3 text-left font-semibold text-slate-600">Pengirim</th>
                        <th class="px-4 py-3 text-left font-semibold text-slate-600">Tgl. Transfer</th>
                        <th class="px-4 py-3 text-left font-semibold text-slate-600">Bukti</th>
                        <th class="px-4 py-3 text-center font-semibold text-slate-600">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if (empty($pwPayments)): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-10 text-center text-slate-400 italic">
                                Tidak ada data pembayaran untuk filter ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($pwPayments as $row):
                        $ps = $row['pay_status'] ?? 'unpaid';
                    ?>
                    <tr class="hover:bg-slate-50 transition <?= $ps === 'pending' ? 'bg-amber-50/40' : '' ?>">
                        <!-- PW Info -->
                        <td class="px-4 py-3">
                            <div class="font-semibold text-slate-800"><?= clean($row['pw_name']) ?></div>
                            <div class="text-xs text-slate-400 font-mono"><?= clean($row['pw_code']) ?></div>
                        </td>
                        <!-- Delegasi -->
                        <td class="px-4 py-3 text-center">
                            <span class="font-bold text-alkhidmah-700"><?= (int)$row['total_participants'] ?></span>
                        </td>
                        <!-- Tagihan -->
                        <td class="px-4 py-3 text-right">
                            <div class="font-semibold text-slate-700"><?= formatRupiah($row['expected_total']) ?></div>
                            <?php if ($row['total_amount'] && $row['total_amount'] != $row['expected_total']): ?>
                                <div class="text-xs text-rose-500">Bayar: <?= formatRupiah($row['total_amount']) ?></div>
                            <?php endif; ?>
                        </td>
                        <!-- Status -->
                        <td class="px-4 py-3"><?= renderPaymentBadge($ps) ?></td>
                        <!-- Pengirim -->
                        <td class="px-4 py-3">
                            <?php if ($row['sender_name']): ?>
                                <div class="font-medium text-slate-700"><?= clean($row['sender_name']) ?></div>
                                <div class="text-xs text-slate-400"><?= clean($row['bank_name'] ?? '') ?></div>
                            <?php else: ?>
                                <span class="text-slate-300">—</span>
                            <?php endif; ?>
                        </td>
                        <!-- Tanggal -->
                        <td class="px-4 py-3 text-xs text-slate-600">
                            <?= $row['payment_date'] ? formatTanggalIndo($row['payment_date']) : '<span class="text-slate-300">—</span>' ?>
                        </td>
                        <!-- Bukti -->
                        <td class="px-4 py-3">
                            <?php if ($row['proof_file']): ?>
                                <?php $ext = strtolower(pathinfo($row['proof_file'], PATHINFO_EXTENSION)); ?>
                                <?php if (in_array($ext, ['jpg','jpeg','png','gif','webp'])): ?>
                                    <a href="<?= BASE_URL . clean($row['proof_file']) ?>" target="_blank"
                                       class="block w-12 h-12 rounded-lg overflow-hidden border border-slate-200 hover:border-amber-400 transition">
                                        <img src="<?= BASE_URL . clean($row['proof_file']) ?>" class="w-full h-full object-cover" alt="Bukti">
                                    </a>
                                <?php else: ?>
                                    <a href="<?= BASE_URL . clean($row['proof_file']) ?>" target="_blank"
                                       class="text-blue-600 hover:underline text-xs font-medium">Lihat PDF</a>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-slate-300 text-xs">—</span>
                            <?php endif; ?>
                        </td>
                        <!-- Aksi -->
                        <td class="px-4 py-3 text-center">
                            <?php if ($row['payment_id']): ?>
                                <div class="flex items-center justify-center gap-1.5">
                                    <?php if ($ps === 'pending'): ?>
                                        <button onclick="openValidateModal(<?= $row['payment_id'] ?>, '<?= addslashes(clean($row['pw_name'])) ?>', '<?= formatRupiah($row['total_amount']) ?>')"
                                                class="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition">
                                            ✓ Validasi
                                        </button>
                                        <button onclick="openRejectModal(<?= $row['payment_id'] ?>, '<?= addslashes(clean($row['pw_name'])) ?>')"
                                                class="px-3 py-1.5 text-xs font-bold bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-lg transition">
                                            ✕ Tolak
                                        </button>
                                    <?php elseif ($ps === 'verified'): ?>
                                        <span class="text-xs text-emerald-600 font-semibold">✅ Lunas</span>
                                        <button onclick="confirmAction(<?= $row['payment_id'] ?>, 'reset', 'Reset status ke Belum Konfirmasi? Ini akan membatalkan verifikasi.')"
                                                class="px-2 py-1 text-xs text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition" title="Reset">
                                            ↩
                                        </button>
                                    <?php elseif ($ps === 'rejected'): ?>
                                        <span class="text-xs text-rose-600 font-semibold">Ditolak</span>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-xs text-slate-300 italic">Belum konfirmasi</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if ($ps === 'rejected' && $row['reject_reason']): ?>
                    <tr class="bg-rose-50">
                        <td colspan="8" class="px-6 py-2">
                            <span class="text-xs text-rose-700">📋 Alasan tolak: <?= clean($row['reject_reason']) ?></span>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Validasi -->
<div id="modal-validate" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4">
    <div class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onclick="closeModal('modal-validate')"></div>
    <div class="relative bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 z-10">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                <svg class="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <div>
                <h2 class="font-bold text-slate-800">Konfirmasi Validasi Pembayaran</h2>
                <p class="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan dengan mudah</p>
            </div>
        </div>
        <div class="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-sm">
            <p>Anda akan memverifikasi pembayaran dari:</p>
            <p class="font-bold text-emerald-800 mt-1" id="modal-validate-pw-name">—</p>
            <p class="text-xs text-emerald-600 mt-1">Jumlah: <span id="modal-validate-amount" class="font-bold">—</span></p>
            <p class="text-xs text-emerald-700 mt-2">✅ Setelah divalidasi, PW dapat mencetak Bukti Pendaftaran / ID Card.</p>
        </div>
        <div class="flex gap-3">
            <button onclick="submitValidate()"
                    class="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition text-sm">
                Ya, Validasi Pembayaran
            </button>
            <button onclick="closeModal('modal-validate')"
                    class="px-5 py-2.5 border border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-slate-50 transition text-sm">
                Batal
            </button>
        </div>
    </div>
</div>

<!-- Modal Tolak -->
<div id="modal-reject" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4">
    <div class="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onclick="closeModal('modal-reject')"></div>
    <div class="relative bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 z-10">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center">
                <svg class="w-5 h-5 text-rose-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </div>
            <div>
                <h2 class="font-bold text-slate-800">Tolak Konfirmasi Pembayaran</h2>
                <p class="text-xs text-slate-500" id="modal-reject-pw-name">PW: —</p>
            </div>
        </div>
        <div>
            <label class="block text-sm font-semibold text-slate-700 mb-1.5">Alasan Penolakan <span class="text-rose-500">*</span></label>
            <textarea id="reject-reason-input" rows="3" placeholder="contoh: Nominal tidak sesuai, bukti tidak terbaca, dll."
                      class="w-full px-4 py-2.5 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-rose-400 resize-none"></textarea>
            <p class="text-xs text-slate-400 mt-1">Alasan ini akan ditampilkan kepada akun PW.</p>
        </div>
        <div class="flex gap-3">
            <button onclick="submitReject()"
                    class="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl transition text-sm">
                Tolak Pembayaran Ini
            </button>
            <button onclick="closeModal('modal-reject')"
                    class="px-5 py-2.5 border border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-slate-50 transition text-sm">
                Batal
            </button>
        </div>
    </div>
</div>

<!-- Toast Notification -->
<div id="toast" class="fixed bottom-6 right-6 z-50 hidden">
    <div id="toast-inner" class="px-5 py-3 rounded-xl shadow-lg text-sm font-semibold text-white flex items-center gap-2">
        <span id="toast-msg"></span>
    </div>
</div>

<script>
let activePaymentId = null;

function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    document.getElementById(id).classList.add('flex');
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    document.getElementById(id).classList.remove('flex');
}

function openValidateModal(payId, pwName, amount) {
    activePaymentId = payId;
    document.getElementById('modal-validate-pw-name').textContent = pwName;
    document.getElementById('modal-validate-amount').textContent = amount;
    openModal('modal-validate');
}

function openRejectModal(payId, pwName) {
    activePaymentId = payId;
    document.getElementById('modal-reject-pw-name').textContent = 'PW: ' + pwName;
    document.getElementById('reject-reason-input').value = '';
    openModal('modal-reject');
}

function submitValidate() {
    postAction({ action: 'verify', payment_id: activePaymentId });
    closeModal('modal-validate');
}

function submitReject() {
    const reason = document.getElementById('reject-reason-input').value.trim();
    if (!reason) {
        alert('Harap isi alasan penolakan.');
        return;
    }
    postAction({ action: 'reject', payment_id: activePaymentId, reject_reason: reason });
    closeModal('modal-reject');
}

function confirmAction(payId, action, msg) {
    if (!confirm(msg)) return;
    postAction({ action: action, payment_id: payId });
}

function postAction(data) {
    const form = new FormData();
    for (let k in data) form.append(k, data[k]);

    fetch(window.location.href, { method: 'POST', body: form })
        .then(r => r.json())
        .then(res => {
            showToast(res.message, res.success ? 'emerald' : 'rose');
            if (res.success) {
                setTimeout(() => window.location.reload(), 1200);
            }
        })
        .catch(() => showToast('Terjadi kesalahan. Coba lagi.', 'rose'));
}

function showToast(msg, color = 'emerald') {
    const toast = document.getElementById('toast');
    const inner = document.getElementById('toast-inner');
    const msgEl = document.getElementById('toast-msg');
    msgEl.textContent = msg;
    inner.className = `px-5 py-3 rounded-xl shadow-lg text-sm font-semibold text-white flex items-center gap-2 bg-${color}-600`;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3500);
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
