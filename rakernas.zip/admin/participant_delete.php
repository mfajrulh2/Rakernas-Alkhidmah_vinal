<?php
/**
 * Hapus Peserta Delegasi
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH
 */

define('APP_INIT', true);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('superadmin');

$id = (int)($_GET['id'] ?? 0);
$pdo = getDB();

$stmtCheck = $pdo->prepare("SELECT full_name FROM participants WHERE id = ?");
$stmtCheck->execute([$id]);
$name = $stmtCheck->fetchColumn();

if ($name) {
    $stmtDel = $pdo->prepare("DELETE FROM participants WHERE id = ?");
    $stmtDel->execute([$id]);
    setFlash('info', "Data delegasi {$name} telah dihapus.");
} else {
    setFlash('danger', "Data peserta tidak ditemukan.");
}

header("Location: " . BASE_URL . "admin/participants.php");
exit;
