# 🌟 SI-RAKERNAS AL KHIDMAH
### Sistem Informasi Manajemen RAKERNAS Perkumpulan Jama'ah Al Khidmah

Aplikasi web-based modern, cepat, dan ringan yang dirancang khusus untuk memfasilitasi kebutuhan **Rapat Kerja Nasional (RAKERNAS) Perkumpulan Jama'ah Al Khidmah**.

---

## 🚀 Fitur Utama

1. **Multi-Role & Akses Pengguna Terintegrasi:**
   - **Super Admin (Panitia Pusat):** Akses penuh ke seluruh data nasional, penataan kamar penginapan, kontrol kuota PW, rundown, dan rekapitulasi.
   - **Admin Pengurus Wilayah (PW):** Login mandiri khusus setiap PW untuk mendaftarkan utusan & peninjau daerah secara kolektif dengan batasan kuota otomatis.
   - **Petugas Meja Registrasi (Front Desk):** Akses cepat pemindai presensi & pembagian kit.

2. **Pendaftaran Kolektif PW (Multi-Row Quick Entry):**
   - Pengurus Wilayah dapat menginput 5–20 nama delegasi sekaligus dalam satu form tabel dinamis tanpa harus mengisi form berulang-ulang.

3. **E-ID Card & QR Code Generator Otomatis:**
   - Setiap delegasi yang terverifikasi mendapatkan E-ID Card berdesain elegan khas Al Khidmah lengkap dengan barcode QR Code unik, komisi sidang, dan nomor kamar.
   - Siap cetak langsung satu per satu atau **Cetak Massal (Batch Print)** dalam format layout lembar A4 (4 kartu per lembar).

4. **Live QR Scanner Presensi Kamera (Fast Check-in):**
   - Pemindaian barcode kamera langsung di browser HP / laptop panitia (tanpa download aplikasi Play Store).
   - Dilengkapi synthesizer audio chime suara sukses/gagal secara instan.
   - Fitur checklist penyerahan **Kit Rakernas / Goodie Bag**.
   - Mendukung alat Barcode Scanner Gun USB / keyboard scan cepat.

5. **Manajemen Kamar & Penginapan:**
   - Pemisahan wisma/kamar Ikhwan & Akhwat, kapasitas tempat tidur (bed), dan daftar nama penghuni per kamar.

6. **Ekspor & Impor Data Excel (CSV):**
   - Download rekap data peserta ke file Excel dengan encoding UTF-8 BOM.
   - Import massal peserta dari spreadsheet Excel/CSV lengkap dengan template contoh.

7. **Portal Mandiri Peserta (Cek Status & E-ID Card):**
   - Peserta cukup memasukkan Nomor WhatsApp / NIK / Kode Registrasi untuk melihat nomor kamar penginapan dan mengunduh E-ID Card mandiri.

---

## 📋 Struktur Folder Aplikasi

```
APP RAKERNAS/
├── admin/                    # Panel Super Admin & Panitia Pusat
│   ├── index.php             # Dashboard statistik real-time
│   ├── participants.php      # Master data delegasi & aksi presensi
│   ├── participant_add.php   # Form tambah delegasi baru
│   ├── participant_edit.php  # Form edit delegasi
│   ├── participant_delete.php# Hapus delegasi
│   ├── pw_accounts.php       # Manajemen akun login & kuota PW
│   ├── rooms.php             # Manajemen kamar wisma penginapan
│   ├── scan.php              # Live camera QR scanner check-in
│   ├── print_cards.php       # Cetak massal ID card (Grid A4)
│   ├── export.php            # Download rekap CSV/Excel
│   ├── import.php            # Upload massal CSV/Excel
│   └── schedules.php         # Manajemen rundown agenda
├── api/
│   └── checkin.php           # API endpoint scanner presensi & kit
├── assets/
│   └── css/
│       └── custom.css        # Styling print ID card & font Khidmah
├── config/
│   └── database.php          # Koneksi MySQL PDO & pengaturan
├── database/
│   └── schema.sql            # Skema tabel MySQL & seed data awal
├── includes/
│   ├── auth.php              # Autentikasi sesi & hak akses role
│   ├── functions.php         # Helper sanitasi, flash alert, QR generator
│   ├── header.php            # Navigasi responsif & Tailwind CDN
│   └── footer.php            # Footer template & skrip JS
├── pw/                       # Portal Khusus Pengurus Wilayah (PW)
│   ├── index.php             # Dashboard PW & kuota
│   ├── participants.php      # Daftar delegasi wilayah
│   ├── register_bulk.php     # Form input kolektif cepat
│   └── print_cards.php       # Cetak ID card delegasi PW
├── .htaccess                 # Konfigurasi Apache hosting
├── check_status.php          # Portal cek mandiri peserta
├── index.php                 # Halaman utama (Landing Page)
├── login.php                 # Halaman login Panitia & PW
├── logout.php                # Logout handler
├── print_card.php            # Tampilan cetak E-ID Card tunggal
├── rundown.php               # Halaman publik jadwal & materi
└── README.md                 # Petunjuk instalasi
```

---

## 💻 Panduan Instalasi Lokal (XAMPP / Laragon)

1. **Letakkan Folder Project:**
   - Salin/pindahkan folder `APP RAKERNAS` ke dalam folder `htdocs` (di XAMPP) atau `www` (di Laragon).
   - Contoh path: `C:/xampp/htdocs/rakernas/`

2. **Buat Database MySQL:**
   - Buka browser dan akses `http://localhost/phpmyadmin`
   - Buat database baru bernama: `db_rakernas_alkhidmah`
   - Klik tab **Import**, pilih file `database/schema.sql`, lalu klik **Import**.

3. **Cek Konfigurasi Database:**
   - Buka file `config/database.php` dan pastikan konfigurasi sesuai:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'root');
     define('DB_PASS', '');
     define('DB_NAME', 'db_rakernas_alkhidmah');
     ```

4. **Akses Aplikasi:**
   - Buka browser ke alamat: `http://localhost/rakernas/`

---

## ☁️ Panduan Deploy ke Cloud Hosting PHP (cPanel)

Karena aplikasi ini dibangun tanpa dependensi kompilasi Node.js/Composer rumit, proses deploy sangat mudah:

1. **Export / Buat Database di cPanel:**
   - Buka **cPanel** > menu **MySQL Databases**.
   - Buat database baru (misal: `u12345_rakernas`) dan user database beserta passwordnya. Berikan hak akses *ALL PRIVILEGES*.
   - Buka **phpMyAdmin** di cPanel, pilih database baru tersebut, klik **Import**, dan upload file `database/schema.sql`.

2. **Upload Berkas Aplikasi:**
   - Compress (ZIP) semua file di dalam folder project ini.
   - Buka **File Manager** cPanel > masuk ke folder tujuan (misal: `public_html` atau subfolder domain `rakernas`).
   - Upload file ZIP dan lakukan **Extract**.

3. **Sesuaikan Konfigurasi `config/database.php`:**
   - Edit file `config/database.php` di cPanel File Manager:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'u12345_useranda');
     define('DB_PASS', 'password_database_anda');
     define('DB_NAME', 'u12345_rakernas');
     ```
   - Simpan perubahan. Aplikasi Anda sudah langsung aktif 100%!

---

## 🔑 Data Akun Login Bawaan (Default Seed)

| Role / Akses | Username | Password | Keterangan |
| :--- | :--- | :--- | :--- |
| **Panitia Pusat** | `admin` | `admin123` | Akses penuh seluruh modul nasional |
| **Petugas Front Desk** | `petugas` | `petugas123` | Akses cepat scan presensi kehadiran |
| **PW Jawa Timur** | `pw_jatim` | `pw123` | Pendaftaran delegasi PW Jatim |
| **PW Jawa Tengah** | `pw_jateng` | `pw123` | Pendaftaran delegasi PW Jateng |
| **PW Jawa Barat** | `pw_jabar` | `pw123` | Pendaftaran delegasi PW Jabar |
| **PW DKI Jakarta** | `pw_dki` | `pw123` | Pendaftaran delegasi PW DKI & Banten |

> *Tips:* Super Admin dapat menambah PW baru, mengatur batas kuota utusan/peninjau, atau mereset password melalui menu **PW & Kuota**.

---

## 📞 Dukungan & Lisensi

Dibuat dengan penuh khidmah untuk menyukseskan perhelatan **Rapat Kerja Nasional Perkumpulan Jama'ah Al Khidmah**.
Semoga acara berjalan lancar, penuh berkah, dan menghasilkan kemaslahatan bagi umat.
