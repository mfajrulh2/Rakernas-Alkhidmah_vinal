-- ========================================================
-- DATABASE SCHEMA: APLIKASI MANAJEMEN RAKERNAS
-- PERKUMPULAN JAMA'AH AL KHIDMAH
-- ========================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- 1. Tabel Wilayah (Pengurus Wilayah / PW Al Khidmah)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `wilayah`;
CREATE TABLE `wilayah` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `province` VARCHAR(100) NOT NULL,
  `quota_utusan` INT NOT NULL DEFAULT 10,
  `quota_peninjau` INT NOT NULL DEFAULT 5,
  `contact_person` VARCHAR(100) DEFAULT NULL,
  `contact_phone` VARCHAR(30) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2. Tabel Users (Super Admin, Admin PW, Petugas Scan)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(60) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(120) NOT NULL,
  `role` ENUM('superadmin', 'admin_pw', 'petugas_scan') NOT NULL DEFAULT 'admin_pw',
  `pw_id` INT DEFAULT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_users_pw` FOREIGN KEY (`pw_id`) REFERENCES `wilayah` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3. Tabel Kamar / Akomodasi Penginapan
-- --------------------------------------------------------
DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `building_name` VARCHAR(100) NOT NULL,
  `room_number` VARCHAR(50) NOT NULL,
  `gender` ENUM('L', 'P', 'Campur') NOT NULL DEFAULT 'L',
  `capacity` INT NOT NULL DEFAULT 4,
  `notes` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4. Tabel Peserta / Delegasi Rakernas
-- --------------------------------------------------------
DROP TABLE IF EXISTS `participants`;
CREATE TABLE `participants` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `registration_code` VARCHAR(40) NOT NULL UNIQUE,
  `nik` VARCHAR(25) DEFAULT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `gender` ENUM('L', 'P') NOT NULL DEFAULT 'L',
  `phone` VARCHAR(30) NOT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `pw_id` INT NOT NULL,
  `pd_name` VARCHAR(120) DEFAULT NULL,
  `jabatan_organisasi` VARCHAR(120) DEFAULT 'Pengurus',
  `participant_type` ENUM('utusan', 'peninjau', 'pengurus_pusat', 'undangan', 'panitia') NOT NULL DEFAULT 'utusan',
  `komisi` VARCHAR(100) NOT NULL DEFAULT 'Komisi A (Organisasi)',
  `room_id` INT DEFAULT NULL,
  `arrival_date` DATETIME DEFAULT NULL,
  `transport_type` VARCHAR(50) DEFAULT 'Mobil Pribadi/Rombongan',
  `status_verifikasi` ENUM('pending', 'verified', 'rejected') NOT NULL DEFAULT 'verified',
  `is_attended` TINYINT(1) NOT NULL DEFAULT 0,
  `attended_at` DATETIME DEFAULT NULL,
  `kit_received` TINYINT(1) NOT NULL DEFAULT 0,
  `kit_received_at` DATETIME DEFAULT NULL,
  `registered_by` INT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_reg_code` (`registration_code`),
  INDEX `idx_pw_id` (`pw_id`),
  INDEX `idx_is_attended` (`is_attended`),
  CONSTRAINT `fk_part_pw` FOREIGN KEY (`pw_id`) REFERENCES `wilayah` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_part_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_part_user` FOREIGN KEY (`registered_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5. Tabel Rundown & Jadwal Kegiatan
-- --------------------------------------------------------
DROP TABLE IF EXISTS `schedules`;
CREATE TABLE `schedules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `session_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `end_time` TIME NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `location` VARCHAR(120) NOT NULL,
  `speaker` VARCHAR(150) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `order_num` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6. Tabel Materi & Dokumen Persidangan
-- --------------------------------------------------------
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Materi Sidang',
  `file_url` TEXT NOT NULL,
  `description` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7. Tabel Pengaturan Sistem (Settings)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` VARCHAR(60) PRIMARY KEY,
  `setting_value` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8. Tabel Pembayaran Iuran Delegasi PW
-- --------------------------------------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_code` VARCHAR(50) NOT NULL UNIQUE,
  `pw_id` INT NOT NULL,
  `total_participants` INT NOT NULL DEFAULT 0,
  `amount_per_person` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `bank_name` VARCHAR(80) DEFAULT NULL,
  `account_number` VARCHAR(80) DEFAULT NULL,
  `sender_name` VARCHAR(120) DEFAULT NULL,
  `payment_date` DATE DEFAULT NULL,
  `proof_file` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('unpaid', 'pending', 'verified', 'rejected') NOT NULL DEFAULT 'unpaid',
  `verified_by` INT DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `reject_reason` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_payments_pw` FOREIGN KEY (`pw_id`) REFERENCES `wilayah` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========================================================
-- DATA AWAL (SEEDS)
-- ========================================================

-- Settings Default
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('event_name', 'Rapat Kerja Nasional (RAKERNAS) Perkumpulan Jama\'ah Al Khidmah'),
('event_theme', 'Meneguhkan Khidmah, Menguatkan Ukhuwah, Menuju Kemandirian Jam\'iyyah'),
('event_date', '15 - 17 November 2026'),
('event_location', 'Pondok Pesantren Assalafi Al Fithrah & Gedung Serbaguna'),
('contact_center', '0812-3456-7890'),
('default_quota_utusan', '10'),
('default_quota_peninjau', '5'),
('registration_open', '1');

-- Wilayah Awal (PW Jamaah Al Khidmah)
INSERT INTO `wilayah` (`code`, `name`, `province`, `quota_utusan`, `quota_peninjau`, `contact_person`, `contact_phone`) VALUES
('PW-JATIM', 'PW Jama\'ah Al Khidmah Jawa Timur', 'Jawa Timur', 15, 10, 'H. M. Syafi\'i', '081234567891'),
('PW-JATENG', 'PW Jama\'ah Al Khidmah Jawa Tengah', 'Jawa Tengah', 12, 8, 'H. Ahmad Fauzi', '081234567892'),
('PW-DIY', 'PW Jama\'ah Al Khidmah D.I. Yogyakarta', 'D.I. Yogyakarta', 10, 5, 'H. Nur Hidayat', '081234567893'),
('PW-JABAR', 'PW Jama\'ah Al Khidmah Jawa Barat', 'Jawa Barat', 10, 5, 'H. Ridwan Malik', '081234567894'),
('PW-DKI', 'PW Jama\'ah Al Khidmah DKI Jakarta & Banten', 'DKI Jakarta', 12, 6, 'H. Lukman Hakim', '081234567895'),
('PW-BALI-NTB', 'PW Jama\'ah Al Khidmah Bali & NTB', 'Bali & NTB', 8, 4, 'H. Subhan', '081234567896'),
('PW-SUMUT', 'PW Jama\'ah Al Khidmah Sumatera Utara', 'Sumatera Utara', 8, 4, 'H. Zulkifli', '081234567897'),
('PW-RIAU', 'PW Jama\'ah Al Khidmah Riau & Kepri', 'Riau', 8, 4, 'H. Syamsul Bahri', '081234567898'),
('PW-SUMSEL', 'PW Jama\'ah Al Khidmah Sumatera Selatan & Lampung', 'Sumatera Selatan', 8, 4, 'H. Mansyur', '081234567899'),
('PW-KALSEL', 'PW Jama\'ah Al Khidmah Kalimantan Selatan', 'Kalimantan Selatan', 10, 5, 'H. Abdul Ghani', '081234567810'),
('PW-KALTIM', 'PW Jama\'ah Al Khidmah Kalimantan Timur', 'Kalimantan Timur', 8, 4, 'H. Mahfudz', '081234567811'),
('PW-SULSEL', 'PW Jama\'ah Al Khidmah Sulawesi Selatan', 'Sulawesi Selatan', 8, 4, 'H. Rusli', '081234567812'),
('PW-LN', 'PW Jama\'ah Al Khidmah Luar Negeri (Malaysia & Singapura)', 'Luar Negeri', 6, 4, 'Ust. Farhan', '+60123456789');

-- Users Default:
-- Password hash untuk 'admin123': $2y$10$vI8aWBnW3fID.ZQ4/zo1G.qPHLeR505v3PhAMx30.G78vGkZomWma
-- Superadmin: admin / admin123
-- Petugas Presensi: petugas / petugas123
-- Admin PW Jatim: pw_jatim / pw123
-- Admin PW Jateng: pw_jateng / pw123
-- Admin PW Jabar: pw_jabar / pw123
-- Admin PW DKI: pw_dki / pw123
INSERT INTO `users` (`username`, `password`, `full_name`, `role`, `pw_id`, `phone`) VALUES
('admin', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Panitia Pusat Rakernas', 'superadmin', NULL, '08110000001'),
('petugas', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Petugas Front Desk Presensi', 'petugas_scan', NULL, '08110000002'),
('pw_jatim', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Admin PW Al Khidmah Jatim', 'admin_pw', 1, '081234567891'),
('pw_jateng', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Admin PW Al Khidmah Jateng', 'admin_pw', 2, '081234567892'),
('pw_diy', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Admin PW Al Khidmah DIY', 'admin_pw', 3, '081234567893'),
('pw_jabar', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Admin PW Al Khidmah Jabar', 'admin_pw', 4, '081234567894'),
('pw_dki', '$2y$10$k1w3Q7J1zF5x4T6G8uK0Oe4LpWv0Qc8zP7.sJ0uK9F5tY3fH2oF7e', 'Admin PW Al Khidmah DKI & Banten', 'admin_pw', 5, '081234567895');

-- Data Kamar Penginapan Contoh
INSERT INTO `rooms` (`building_name`, `room_number`, `gender`, `capacity`, `notes`) VALUES
('Wisma Utama (Ikhwan)', 'Kamar 101', 'L', 4, 'Lantai 1, AC, Kamar Mandi Dalam'),
('Wisma Utama (Ikhwan)', 'Kamar 102', 'L', 4, 'Lantai 1, AC, Kamar Mandi Dalam'),
('Wisma Utama (Ikhwan)', 'Kamar 103', 'L', 4, 'Lantai 1, AC, Kamar Mandi Dalam'),
('Wisma Khodijah (Akhwat)', 'Kamar 201', 'P', 4, 'Lantai 2, AC, Kamar Mandi Dalam'),
('Wisma Khodijah (Akhwat)', 'Kamar 202', 'P', 4, 'Lantai 2, AC, Kamar Mandi Dalam'),
('Gedung Tamu VIP', 'Kamar VIP 01', 'L', 2, 'Khusus Masyaikh / Pengurus Pusat');

-- Data Contoh Peserta
INSERT INTO `participants` (`registration_code`, `nik`, `full_name`, `gender`, `phone`, `email`, `pw_id`, `pd_name`, `jabatan_organisasi`, `participant_type`, `komisi`, `room_id`, `status_verifikasi`, `is_attended`, `kit_received`) VALUES
('RKN-JTM-001', '3578010101850001', 'KH. Muhammad Najib', 'L', '081234567801', 'najib@alkhidmah.org', 1, 'PD Surabaya', 'Ketua PD', 'utusan', 'Komisi A (Organisasi)', 1, 'verified', 0, 0),
('RKN-JTM-002', '3578010101850002', 'H. Agus Salim, S.Pd.I', 'L', '081234567802', 'agus@alkhidmah.org', 1, 'PD Gresik', 'Sekretaris PD', 'utusan', 'Komisi B (Program Kerja)', 1, 'verified', 0, 0),
('RKN-JTG-001', '3374010101860001', 'Drs. H. Subhan Mubarok', 'L', '081234567803', 'subhan@alkhidmah.org', 2, 'PD Semarang', 'Ketua PD', 'utusan', 'Komisi C (Rekomendasi & Keuangan)', 2, 'verified', 0, 0),
('RKN-DKI-001', '3171010101870001', 'H. Faisal Rizal, SE', 'L', '081234567804', 'faisal@alkhidmah.org', 5, 'PD Jakarta Selatan', 'Biro Organisasi', 'utusan', 'Komisi A (Organisasi)', 3, 'verified', 0, 0),
('RKN-JTM-003', '3578010101880003', 'Hj. Siti Aminah, M.Pd', 'P', '081234567805', 'aminah@alkhidmah.org', 1, 'PD Sidoarjo', 'Ketua Wanita Jamaah', 'peninjau', 'Komisi B (Program Kerja)', 4, 'verified', 0, 0);

-- Data Jadwal / Rundown Contoh
INSERT INTO `schedules` (`session_date`, `start_time`, `end_time`, `title`, `location`, `speaker`, `description`, `order_num`) VALUES
('2026-11-15', '13:00:00', '17:00:00', 'Registrasi Ulang Peserta & Check-in Penginapan', 'Lobi Gedung Serbaguna', 'Panitia Kesekretariatan', 'Verifikasi berkas mandat, scan barcode, penyerahan Kit Rakernas dan kunci kamar.', 1),
('2026-11-15', '19:30:00', '22:00:00', 'Pembukaan RAKERNAS & Majlis Dzikir Maulidurrasul SAW', 'Aula Utama', 'Majelis Ilmi & Pengurus Pusat', 'Pembukaan resmi oleh Ketua Umum & Doa Bersama untuk Keselamatan Bangsa.', 2),
('2026-11-16', '08:30:00', '11:45:00', 'Sidang Pleno I: Laporan Kinerja Pengurus Pusat', 'Aula Utama', 'Pimpinan Sidang Pleno', 'Penyampaian laporan pertanggungjawaban program kerja berjalan.', 3),
('2026-11-16', '13:15:00', '16:30:00', 'Sidang Komisi (A: Organisasi, B: Program, C: Rekomendasi)', 'Ruang Komisi Masing-masing', 'Ketua Tiap Komisi', 'Pembahasan mendalam strategi jam\'iyyah, kaderisasi, dan kemandirian.', 4),
('2026-11-16', '19:30:00', '21:30:00', 'Sidang Pleno II: Pengesahan Hasil Sidang Komisi', 'Aula Utama', 'Presidium Sidang', 'Penetapan keputusan resmi Rakernas dan penandatanganan berita acara.', 5),
('2026-11-17', '08:00:00', '10:30:00', 'Penutupan Resmi & Ramah Tamah Delegasi', 'Aula Utama', 'Panitia & Masyaikh', 'Penyerahan cinderamata dan pelepasan kepulangan kafilah.', 6);

SET FOREIGN_KEY_CHECKS = 1;
