<?php
/**
 * Dokumen Bukti Pendaftaran Resmi Delegasi (Print View / PDF)
 * RAKERNAS PERKUMPULAN JAMA'AH AL KHIDMAH 2026
 * 
 * Dibawa dan ditunjukkan kepada petugas saat delegasi tiba di lokasi Rakernas
 */

define('APP_INIT', true);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();

$code  = trim($_GET['code'] ?? '');
$token = trim($_GET['token'] ?? '');
$all   = isset($_GET['all']) && $_GET['all'] == '1';

$participants = [];
$pw = null;
$pwIdParam = (int)($_GET['pw_id'] ?? 0);

if (!empty($token)) {
    $pw = getWilayahByRegToken($token);
} elseif ($pwIdParam > 0) {
    $stmtPW = $pdo->prepare("SELECT * FROM wilayah WHERE id = ?");
    $stmtPW->execute([$pwIdParam]);
    $pw = $stmtPW->fetch();
}

// Skenario 1: Cetak Semua Delegasi untuk PW tertentu (Batch Mode)
if ($all && $pw) {
    $stmt = $pdo->prepare("
        SELECT p.*, w.name AS pw_name, w.code AS pw_code, w.province AS pw_province,
               r.building_name, r.room_number,
               pay.status AS payment_status, pay.invoice_code
        FROM participants p
        LEFT JOIN wilayah w ON p.pw_id = w.id
        LEFT JOIN rooms r ON p.room_id = r.id
        LEFT JOIN payments pay ON pay.pw_id = p.pw_id AND pay.status = 'verified'
        WHERE p.pw_id = ?
        ORDER BY p.id ASC
    ");
    $stmt->execute([$pw['id']]);
    $participants = $stmt->fetchAll();

    if (empty($participants)) {
        die("Belum ada data delegasi terdaftar untuk wilayah ini.");
    }
}
// Skenario 2: Cetak Tunggal berdasarkan registration_code
elseif (!empty($code)) {
    $stmt = $pdo->prepare("
        SELECT p.*, w.name AS pw_name, w.code AS pw_code, w.province AS pw_province,
               r.building_name, r.room_number,
               pay.status AS payment_status, pay.invoice_code
        FROM participants p
        LEFT JOIN wilayah w ON p.pw_id = w.id
        LEFT JOIN rooms r ON p.room_id = r.id
        LEFT JOIN payments pay ON pay.pw_id = p.pw_id AND pay.status = 'verified'
        WHERE p.registration_code = ?
        LIMIT 1
    ");
    $stmt->execute([$code]);
    $p = $stmt->fetch();

    if (!$p) {
        die("Data delegasi tidak ditemukan.");
    }
    $participants = [$p];
    if (!$pw && !empty($p['pw_id'])) {
        $stmtPW = $pdo->prepare("SELECT * FROM wilayah WHERE id = ?");
        $stmtPW->execute([$p['pw_id']]);
        $pw = $stmtPW->fetch();
    }
} else {
    die("Parameter pendaftaran tidak valid.");
}

// Info Pembayaran PW
$pwId = $pw['id'] ?? ($participants[0]['pw_id'] ?? 0);
$payInfo = $pwId ? getPWPaymentInfo($pwId) : null;
$isPaymentVerified = ($payInfo && $payInfo['is_verified']);

$appLogoUrl = getAppLogoUrl();
$eventDate  = getSetting('event_date', '15 - 17 November 2026');
$eventPlace = getSetting('event_location', 'Pondok Pesantren Assalafi Al Fithrah, Surabaya');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bukti Pendaftaran Delegasi RAKERNAS 2026 <?= count($participants) === 1 ? '- ' . clean($participants[0]['full_name']) : '- ' . clean($pw['name'] ?? '') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/custom.css">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm 12mm 10mm 12mm;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            .proof-page {
                box-shadow: none !important;
                border: 1px solid #e2e8f0 !important;
                margin: 0 !important;
                page-break-after: always;
                break-after: page;
                padding: 10mm 12mm !important;
                min-height: 275mm !important;
            }
            .proof-page:last-child {
                page-break-after: auto;
                break-after: auto;
            }
        }
        .proof-page {
            width: 210mm;
            min-height: 285mm;
            box-sizing: border-box;
            background: #ffffff;
            margin: 0 auto 15mm auto;
            position: relative;
        }
    </style>
</head>
<body class="bg-slate-100 min-h-screen py-6">

    <!-- Action Toolbar (Hidden on Print) -->
    <div class="no-print max-w-4xl mx-auto mb-6 px-4 flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            </div>
            <div>
                <h1 class="text-sm font-extrabold text-slate-800">
                    Dokumen Bukti Pendaftaran Resmi Delegasi
                </h1>
                <p class="text-xs text-slate-500">
                    <?= count($participants) === 1 ? '1 Dokumen Siap Cetak' : count($participants) . ' Dokumen Delegasi Siap Cetak' ?> • Format Kertas A4
                </p>
            </div>
        </div>

        <div class="flex items-center gap-2">
            <button onclick="window.print()" class="px-5 py-2.5 rounded-xl bg-emerald-700 text-white font-bold text-xs hover:bg-emerald-800 transition shadow flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                <span>Cetak / Simpan PDF</span>
            </button>
            <button onclick="window.close()" class="px-4 py-2.5 rounded-xl bg-slate-100 border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-200 transition">
                Tutup
            </button>
        </div>
    </div>

    <!-- Container Lembar Bukti Pendaftaran -->
    <div class="max-w-4xl mx-auto">
        <?php foreach ($participants as $delIndex => $del): ?>
            <?php
            $qrData = $del['registration_code'];
            $qrUrl  = getQRCodeUrl($qrData, 220);
            $genderText = ($del['gender'] ?? 'L') === 'P' ? 'Perempuan' : 'Laki-laki';
            $delTypeLabel = strtoupper($del['participant_type'] ?? 'UTUSAN');
            ?>

            <div class="proof-page p-8 sm:p-10 rounded-2xl shadow-xl border border-slate-200 flex flex-col justify-between">
                
                <div>
                    <!-- KOP SURAT RESMI -->
                    <div class="flex items-center gap-4 pb-4">
                        <div class="w-20 h-20 shrink-0 flex items-center justify-center">
                            <?php if ($appLogoUrl): ?>
                                <img src="<?= $appLogoUrl ?>" alt="Logo Al Khidmah" class="w-20 h-20 object-contain">
                            <?php else: ?>
                                <div class="w-20 h-20 rounded-2xl bg-emerald-900 text-amber-400 flex flex-col items-center justify-center font-bold text-center p-1.5 shadow-sm">
                                    <svg class="w-10 h-10 text-amber-400" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                                    </svg>
                                    <span class="text-[8px] tracking-tighter leading-tight mt-0.5 text-white font-serif uppercase">Al Khidmah</span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="flex-grow text-center">
                            <h2 class="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-emerald-950 font-serif">
                                Panitia Pelaksana Rapat Kerja Nasional (RAKERNAS) 2026
                            </h2>
                            <h1 class="text-base sm:text-xl font-extrabold uppercase tracking-tight text-emerald-900 mt-0.5">
                                Perkumpulan Jama'ah Al Khidmah
                            </h1>
                            <p class="text-[10px] text-slate-600 mt-0.5 leading-snug">
                                Sekretariat: Pondok Pesantren Assalafi Al Fithrah, Jl. Kedinding Lor No. 99, Kenjeran, Surabaya, Jawa Timur 60129<br>
                                Website: www.alkhidmah.org • Email: rakernas@alkhidmah.org
                            </p>
                        </div>
                    </div>

                    <!-- GARIS KOP DOUBLE (EMERALD & GOLD) -->
                    <div class="relative mb-5">
                        <div class="h-1 bg-emerald-900"></div>
                        <div class="h-0.5 bg-amber-500 mt-0.5"></div>
                    </div>

                    <!-- JUDUL DOKUMEN & KODE REGISTRASI -->
                    <div class="text-center mb-6">
                        <div class="inline-block border-b-2 border-emerald-900 pb-1">
                            <h3 class="text-sm sm:text-base font-extrabold text-slate-900 tracking-wider uppercase">
                                Surat Tanda Bukti Pendaftaran Resmi Delegasi
                            </h3>
                        </div>
                        <div class="mt-2 flex items-center justify-center gap-3">
                            <span class="text-xs text-slate-600">Nomor Registrasi:</span>
                            <span class="font-mono text-sm sm:text-base font-black px-3 py-0.5 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-900 tracking-wider">
                                <?= clean($del['registration_code']) ?>
                            </span>
                        </div>
                    </div>

                    <!-- KONTEN UTAMA: DUA KOLOM (IDENTITAS & QR CODE/FOTO) -->
                    <div class="grid grid-cols-12 gap-5 mb-5 items-start">
                        
                        <!-- KOLOM KIRI: TABEL IDENTITAS LENGKAP -->
                        <div class="col-span-8 bg-slate-50/60 rounded-2xl border border-slate-200 p-4">
                            <table class="w-full text-xs text-slate-800">
                                <tbody>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold w-36">Nama Lengkap & Gelar</td>
                                        <td class="py-1.5 font-bold text-slate-900 text-sm">: <?= clean($del['full_name']) ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Jenis Kelamin</td>
                                        <td class="py-1.5">: <?= $genderText ?> (<?= clean($del['gender']) ?>)</td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Unsur Organisasi</td>
                                        <td class="py-1.5 font-bold text-emerald-800">: <?= clean($del['unsur_organisasi'] ?? 'Al Khidmah') ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Pengurus Wilayah (PW)</td>
                                        <td class="py-1.5 font-semibold text-slate-900">: <?= clean($del['pw_name'] ?? $pw['name'] ?? '-') ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Pengurus Daerah (PD)</td>
                                        <td class="py-1.5">: <?= clean($del['pd_name'] ?: '-') ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Jabatan / Bidang</td>
                                        <td class="py-1.5">: <?= clean($del['jabatan_organisasi'] ?: '-') ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Klasifikasi Peserta</td>
                                        <td class="py-1.5">
                                            : <span class="font-bold uppercase <?= ($del['participant_type'] ?? '') === 'peninjau' ? 'text-amber-700' : 'text-emerald-800' ?>">
                                                PESERTA <?= clean($delTypeLabel) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Komisi Sidang</td>
                                        <td class="py-1.5 font-bold text-slate-900">: <?= clean($del['komisi']) ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Nomor WhatsApp / HP</td>
                                        <td class="py-1.5 font-mono">: <?= clean($del['phone']) ?></td>
                                    </tr>
                                    <tr class="border-b border-slate-200/80">
                                        <td class="py-1.5 text-slate-500 font-semibold">Status Iuran PW</td>
                                        <td class="py-1.5">
                                            : <?php if ($isPaymentVerified): ?>
                                                <span class="font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded text-[11px] border border-emerald-300">
                                                    TERVERIFIKASI / LUNAS
                                                </span>
                                            <?php else: ?>
                                                <span class="font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded text-[11px] border border-amber-300">
                                                    MENUNGGU VALIDASI PANITIA
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="py-1.5 text-slate-500 font-semibold">Penginapan / Kamar</td>
                                        <td class="py-1.5 font-semibold text-slate-800">
                                            : <?= !empty($del['building_name']) ? clean($del['building_name'] . ' - Kamar ' . $del['room_number']) : 'Ditetapkan di Meja Registrasi Lokasi' ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- KOLOM KANAN: FOTO & QR CODE CHECK-IN -->
                        <div class="col-span-4 flex flex-col items-center justify-center space-y-3">
                            <!-- Foto Delegasi -->
                            <?php if (!empty($del['photo_file'])): ?>
                                <div class="bg-white p-1 rounded-2xl border-2 border-emerald-800 shadow-sm">
                                    <img src="<?= BASE_URL . clean($del['photo_file']) ?>" alt="Foto Delegasi" class="w-24 h-32 object-cover rounded-xl">
                                </div>
                            <?php else: ?>
                                <div class="w-24 h-32 rounded-xl bg-slate-100 border border-slate-300 flex flex-col items-center justify-center text-slate-400 p-2 text-center text-[10px]">
                                    <svg class="w-8 h-8 text-slate-300 mb-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                                    <span>Foto Resmi</span>
                                </div>
                            <?php endif; ?>

                            <!-- QR Code Box -->
                            <div class="bg-white p-2.5 rounded-2xl border-2 border-emerald-800 shadow-md text-center w-full max-w-[190px]">
                                <img src="<?= $qrUrl ?>" alt="QR Code Registrasi" class="w-36 h-36 mx-auto object-contain">
                                <div class="text-[9px] uppercase tracking-wider font-extrabold text-emerald-950 mt-1.5">
                                    QR CODE CHECK-IN
                                </div>
                                <div class="text-[8px] text-slate-500 font-mono">
                                    <?= clean($del['registration_code']) ?>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- KOTAK PETUNJUK KEDATANGAN RAKERNAS -->
                    <div class="bg-emerald-50/70 border border-emerald-300/80 rounded-2xl p-4 text-xs text-slate-800">
                        <div class="font-extrabold text-emerald-950 flex items-center gap-1.5 mb-1.5 uppercase tracking-wide text-[11px]">
                            <svg class="w-4 h-4 text-emerald-700" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
                            PENTING: HARAP DIBAWA & DITUNJUKKAN KEPADA PETUGAS SAAT TIBA DI LOKASI RAKERNAS
                        </div>
                        <ol class="list-decimal list-inside space-y-1 text-[11px] text-slate-700 leading-relaxed pl-1">
                            <li><strong>Bawa Dokumen Ini:</strong> Cetak dokumen bukti ini atau simpan format PDF pada ponsel Anda untuk ditunjukkan kepada petugas meja kedatangan RAKERNAS.</li>
                            <li><strong>Verifikasi QR Code:</strong> Petugas akan memindai QR Code di atas untuk validasi kehadiran kedatangan, pengambilan <strong>ID Card Resmi</strong>, tas seminar kit, dan penyerahan kunci penginapan.</li>
                            <li><strong>Tata Busana:</strong> Seluruh peserta diwajibkan mengenakan busana muslim rapi dengan <strong>baju putih dan kopiah putih</strong> selama seluruh rangkaian acara Rakernas.</li>
                            <li><strong>Waktu Pelaksanaan:</strong> Tanggal <strong><?= clean($eventDate) ?></strong> di <strong><?= clean($eventPlace) ?></strong>.</li>
                        </ol>
                    </div>
                </div>

                <!-- BAGIAN PENGESAHAN & TANDA TANGAN -->
                <div class="mt-6 pt-4 border-t border-slate-200">
                    <div class="flex items-end justify-between text-xs text-slate-600">
                        <div>
                            <p class="text-[10px] text-slate-400">
                                Dicetak otomatis melalui Portal Resmi RAKERNAS 2026<br>
                                Waktu Cetak: <?= date('d/m/Y H:i:s') ?> WIB • Status: Valid
                            </p>
                        </div>

                        <div class="text-center w-64">
                            <p class="text-[11px]">Surabaya, <?= formatTanggalIndo(date('Y-m-d')) ?></p>
                            <p class="text-[11px] font-bold text-slate-800 mt-0.5">Panitia Pelaksana RAKERNAS 2026<br>Perkumpulan Jama'ah Al Khidmah</p>
                            
                            <!-- Stempel & Tanda Tangan Box -->
                            <div class="h-16 flex items-center justify-center my-1 relative">
                                <div class="w-20 h-20 rounded-full border-2 border-emerald-700/40 text-emerald-800/40 font-bold flex flex-col items-center justify-center text-[8px] uppercase tracking-tighter rotate-[-12deg] pointer-events-none">
                                    <span>PANITIA</span>
                                    <span class="text-[10px] text-amber-600 font-extrabold">RAKERNAS</span>
                                    <span>2026</span>
                                </div>
                            </div>

                            <p class="font-extrabold text-slate-900 text-xs underline">SC & OC RAKERNAS 2026</p>
                            <p class="text-[10px] text-slate-500">Sekretariat Panitia Pusat</p>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
